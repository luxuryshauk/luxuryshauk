package com.instaasell.Home;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.instaasell.R;
import com.instaasell.Share.NextActivity;
import com.instaasell.Utils.FirebaseMethods;
import com.instaasell.Utils.UniversalImageLoader;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class AddActivity extends AppCompatActivity {

    private static final String TAG = "AddActivity";

    //firebase
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference myRef;
    private FirebaseMethods mFirebaseMethods;

    private StorageReference mStorageReference;
    private String userID;

    //widgets
    private EditText mCaption;

    //vars
    private String mAppend = "file:/";
    private int imageCount = 0;
    private String imgUrl;
    private Bitmap bitmap;
    private Intent intent;
    private EditText mPrice;
    private TextView mPrice_com,mPrice_earn;
    public double price;
    public Context mContext;

    public AddActivity() {
        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        mStorageReference = FirebaseStorage.getInstance().getReference();
        if(mAuth.getCurrentUser() != null){
            userID = mAuth.getCurrentUser().getUid();
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(AddActivity.this,HomeActivity.class));
        finish();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_to_my_store);
        mFirebaseMethods = new FirebaseMethods(AddActivity.this);
        mCaption = (EditText) findViewById(R.id.caption) ;
        Bundle b = getIntent().getExtras();
        mCaption.setText(b.getString("caption"));
//        mPrice.setText(b.getString("price"));


        Thread t = new Thread() {
            @Override
            public void run() {
                while (!isInterrupted()) {
                    try {
                        Thread.sleep(1000);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                getCommision();
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        t.start();


        setupFirebaseAuth();

        ImageView backArrow = (ImageView) findViewById(R.id.ivBackArrow);
        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: closing the activity");
                startActivity(new Intent(AddActivity.this,HomeActivity.class));
                finish();
            }
        });


        TextView share = (TextView) findViewById(R.id.tvShare);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mPrice = (EditText)findViewById(R.id.price);
                if(!mPrice.getText().toString().equals(""))
                {
                    final float price = Float.parseFloat(mPrice.getText().toString());
                }
                else {
                    final float price = 0;
                }
                Log.d(TAG, "onClick: navigating to the final share screen.");
                //upload the image to firebase
                Toast.makeText(AddActivity.this, "Attempting to upload new photo", Toast.LENGTH_SHORT).show();
                final String caption = mCaption.getText().toString();
                Bundle b = intent.getExtras();
                Picasso.get().load(b.getString("img_url")).into(new Target() {
                    @Override
                    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                            mFirebaseMethods.uploadNewPhoto(getString(R.string.new_photo), caption, imageCount, null,bitmap,(float)price,1);
                    }
                    @Override
                    public  void onBitmapFailed(Exception e, Drawable errorDrawable) {
                        Toast.makeText(AddActivity.this, "Failed to load image", Toast.LENGTH_SHORT).show();
                    }
                    @Override
                    public void onPrepareLoad(Drawable placeHolderDrawable) {
                        Toast.makeText(AddActivity.this, "Preparing Photo", Toast.LENGTH_SHORT).show();
                    }

                });
//                if(intent.hasExtra("img_url")){
//                    Bundle b = getIntent().getExtras();
//
//                    imgUrl = intent.getStringExtra(b.getString("img_url"));
//                    mFirebaseMethods.uploadNewPhoto(getString(R.string.new_photo), caption, imageCount, imgUrl,null,(float)price);
//                }
//                else if(intent.hasExtra(getString(R.string.selected_bitmap))){
//                    bitmap = (Bitmap) intent.getParcelableExtra(getString(R.string.selected_bitmap));
//                    mFirebaseMethods.uploadNewPhoto(getString(R.string.new_photo), caption, imageCount, null,bitmap,(float)price);
//                }
            }
        });

        setImage();
    }



    public Uri getLocalBitmapUri(Bitmap bmp)
    {
        Uri bmpUri = null;
        try{
            File file = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),"share_image" + System.currentTimeMillis() + ".png");
            FileOutputStream out = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.PNG,90,out);
            out.close();
            bmpUri = Uri.fromFile(file);
        }catch (IOException e)
        {
            e.printStackTrace();
        }
        return bmpUri;
    }

    public float getCommision()
    {

        mPrice = (EditText)findViewById(R.id.price);
        mPrice_com = (TextView) findViewById(R.id.price_com);
        mPrice_earn = (TextView) findViewById(R.id.price_earn);
        double price=0,price_com=0,price_earn=0;
        if(TextUtils.isEmpty(mPrice.getText()))
        {
            price = 0f;
        }
        else
        {

            price = Double.parseDouble(mPrice.getText().toString());
            price_com = price * .05;
            price_earn = price - price_com;
        }

        int price_com_round = (int)Math.ceil(price_com);
        int price_ear_round = (int)Math.floor(price_earn);

        mPrice_com.setText("Instaasell Charge : (-) ₹ "+Integer.toString(price_com_round));
        mPrice_earn.setText("You Earn :              (+) ₹ "+Integer.toString(price_ear_round));
        return (float)price;
    }

    private void someMethod(){
        /*
            Step 1)
            Create a data model for Photos

            Step 2)
            Add properties to the Photo Objects (caption, date, imageUrl, photo_id, tags, user_id)

            Step 3)
            Count the number of photos that the user already has.

            Step 4)
            a) Upload the photo to Firebase Storage
            b) insert into 'photos' node
            c) insert into 'user_photos' node

         */

    }


    /**
     * gets the image url from the incoming intent and displays the chosen image
     */
    private void setImage(){
        intent = getIntent();
        final ImageView image = (ImageView) findViewById(R.id.imageShare);
        Bundle b = intent.getExtras();
        Picasso.get().load(b.getString("img_url")).into(image);//new Target() {
//            @Override
//            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
//                Picasso.get().load(getLocalBitmapUri(bitmap)).into(image);
//            }
//
//            @Override
//            public void onBitmapFailed(Exception e, Drawable errorDrawable) {
//            }
//
//            @Override
//            public void onPrepareLoad(Drawable placeHolderDrawable) {
//            }
//        });

//        if(intent.hasExtra("img_url")){
//            imgUrl = intent.getStringExtra("img_url");
//            Log.d(TAG, "setImage: got new image url: " + imgUrl);
//            UniversalImageLoader.setImage(imgUrl, image, null, mAppend);
//        }
//        else if(intent.hasExtra("img_url")){
//            bitmap = (Bitmap) intent.getParcelableExtra("img_url");
//            Log.d(TAG, "setImage: got new bitmap");
//            image.setImageBitmap(bitmap);
//        }
//        Bundle b = intent.getExtras();
//        Picasso.get().load(b.getString("img_url")).into(image);
    }

     /*
     ------------------------------------ Firebase ---------------------------------------------
     */

    /**
     * Setup the firebase auth object
     */
    private void setupFirebaseAuth(){
        Log.d(TAG, "setupFirebaseAuth: setting up firebase auth.");
        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        Log.d(TAG, "onDataChange: image count: " + imageCount);

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();


                if (user != null) {
                    // User is signed in
                    Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
                } else {
                    // User is signed out
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                }
                // ...
            }
        };


        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                imageCount = mFirebaseMethods.getImageCount(dataSnapshot);
                Log.d(TAG, "onDataChange: image count: " + imageCount);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }


    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }
}
