package com.instaasell.models;

public class notification {

    public String type;
    public String by_user;
    public String seen;
    public String time;

    public notification()
    {}

    public notification(String type, String by_user, String seen, String time) {
        this.type = type;
        this.by_user = by_user;
        this.seen = seen;
        this.time = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBy_user() {
        return by_user;
    }

    public void setBy_user(String by_user) {
        this.by_user = by_user;
    }

    public String getSeen() {
        return seen;
    }

    public void setSeen(String seen) {
        this.seen = seen;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
