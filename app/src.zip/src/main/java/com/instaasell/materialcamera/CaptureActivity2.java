package com.instaasell.materialcamera;

import android.app.Fragment;
import android.support.annotation.NonNull;

import com.instaasell.materialcamera.internal.BaseCaptureActivity;
import com.instaasell.materialcamera.internal.Camera2Fragment;


public class CaptureActivity2 extends BaseCaptureActivity {

  @Override
  @NonNull
  public Fragment getFragment() {
    return Camera2Fragment.newInstance();
  }
}
