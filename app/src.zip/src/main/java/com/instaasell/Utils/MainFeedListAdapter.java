package com.instaasell.Utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.request.target.Target;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.security.PolicySpi;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import de.hdodenhof.circleimageview.CircleImageView;
import com.instaasell.Home.HomeActivity;
import com.instaasell.Profile.ProfileActivity;
import com.instaasell.R;
import com.instaasell.models.Comment;
import com.instaasell.models.Like;
import com.instaasell.models.Photo;
import com.instaasell.models.User;
import com.instaasell.models.UserAccountSettings;

/**
 * Created by User on 9/22/2017.
 */

public class MainFeedListAdapter extends ArrayAdapter<Photo> {

    public interface OnLoadMoreItemsListener{
        void onLoadMoreItems();
    }
    OnLoadMoreItemsListener mOnLoadMoreItemsListener;

    private static final String TAG = "MainFeedListAdapter";



    private LayoutInflater mInflater;
    private int mLayoutResource,i;
    private Context mContext;
    private DatabaseReference mReference;
    private String currentUsername = "";
    private int counter;
    private ArrayList<String> img_urls = new ArrayList<>();
    private String[] img__url;
    ListView listView=null;
    ArrayList<Bitmap> files = new ArrayList<Bitmap>();


    public MainFeedListAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<Photo> objects) {
        super(context, resource, objects);
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mLayoutResource = resource;
        this.mContext = context;
        mReference = FirebaseDatabase.getInstance().getReference();


//        for(Photo photo: objects){
//            Log.d(TAG, "MainFeedListAdapter: photo id: " + photo.getPhoto_id());
//        }
    }

    public static class ViewHolder{
        CircleImageView mprofileImage;
        String likesString;
        TextView username, timeDetla, caption, likes, comments;
        SquareImageView image;
        ImageView heartRed, heartWhite, comment,save_to_my_store;
        ImageView[] sharePhoto = new ImageView[10];
        TextView price;
        Button Buy_btn;
        ImageView share_btn;
        ImageButton ismultiple;
        UserAccountSettings settings = new UserAccountSettings();
        User user  = new User();
        StringBuilder users;
        String mLikesString;
        boolean likeByCurrentUser;
        Heart heart;
        GestureDetector detector;
        Photo photo;
        Button buy_now;
        ImageView option;

    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        final ViewHolder holder;

        listView = new ListView((HomeActivity)mContext);

        if(convertView == null){
            convertView = mInflater.inflate(mLayoutResource, parent, false);
            holder = new ViewHolder();
            holder.username = (TextView) convertView.findViewById(R.id.username);
            holder.price = (TextView) convertView.findViewById(R.id.price_display);
            holder.image = (SquareImageView) convertView.findViewById(R.id.post_image);
            holder.heartRed = (ImageView) convertView.findViewById(R.id.image_heart_red);
            holder.heartWhite = (ImageView) convertView.findViewById(R.id.image_heart);
            holder.comment = (ImageView) convertView.findViewById(R.id.speech_bubble);
            holder.likes = (TextView) convertView.findViewById(R.id.image_likes);
            holder.comments = (TextView) convertView.findViewById(R.id.image_comments_link);
            holder.caption = (TextView) convertView.findViewById(R.id.image_caption);
            holder.timeDetla = (TextView) convertView.findViewById(R.id.image_time_posted);
            holder.mprofileImage = (CircleImageView) convertView.findViewById(R.id.profile_photo);
            holder.Buy_btn = (Button) convertView.findViewById(R.id.buyButton);
            holder.save_to_my_store = (ImageView) convertView.findViewById(R.id.btn_save);
            holder.share_btn = (ImageView) convertView.findViewById(R.id.share_btn);
            holder.option = (ImageView)convertView.findViewById(R.id.ivEllipses);
            holder.buy_now = (Button) convertView.findViewById(R.id.buyButton);
            holder.ismultiple = (ImageButton) convertView.findViewById(R.id.ismultiple);

            holder.sharePhoto[0] = (ImageView) convertView.findViewById(R.id.sp0);
            holder.sharePhoto[1] = (ImageView) convertView.findViewById(R.id.sp1);
            holder.sharePhoto[2] = (ImageView) convertView.findViewById(R.id.sp2);
            holder.sharePhoto[3] = (ImageView) convertView.findViewById(R.id.sp3);
            holder.sharePhoto[4] = (ImageView) convertView.findViewById(R.id.sp4);
            holder.sharePhoto[5] = (ImageView) convertView.findViewById(R.id.sp5);
            holder.sharePhoto[6] = (ImageView) convertView.findViewById(R.id.sp6);
            holder.sharePhoto[7] = (ImageView) convertView.findViewById(R.id.sp7);
            holder.Buy_btn.setVisibility(View.GONE);
            convertView.setTag(holder);
        }
        else{
            holder = (ViewHolder) convertView.getTag();
        }

        holder.photo = getItem(position);
        holder.detector = new GestureDetector(mContext, new GestureListener(holder));
        holder.users = new StringBuilder();
        holder.heart = new Heart(holder.heartWhite, holder.heartRed);

        //get the current users username (need for checking likes string)
        getCurrentUsername();


        //get likes string
        getLikesString(holder);

        //set the caption
        holder.caption.setText(getItem(position).getCaption());

        final String capton = getItem(position).getCaption();

        //set the comment
        List<Comment> comments = getItem(position).getComments();
        holder.comments.setText("View all " + comments.size() + " comments");
        holder.comments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: loading comment thread for " + getItem(position).getPhoto_id());
                ((HomeActivity)mContext).onCommentThreadSelected(getItem(position),
                        mContext.getString(R.string.home_activity));

                //going to need to do something else?
                ((HomeActivity)mContext).hideLayout();

            }
        });

        //set the time it was posted
        String timestampDifference = getTimestampDifference(getItem(position));
        if(!timestampDifference.equals("0")){
            holder.timeDetla.setText(timestampDifference + " DAYS AGO");
        }else{
            holder.timeDetla.setText("TODAY");
        }

        //set the profile image
        final ImageLoader imageLoader = ImageLoader.getInstance();
        final String path_to_image = getItem(position).getImage_path();







//        DatabaseReference img_ref = FirebaseDatabase.getInstance().getReference().child();


        imageLoader.displayImage(getItem(position).getImage_path(), holder.image);


        //get the profile image and username
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        Query query = reference
                .child(mContext.getString(R.string.dbname_user_account_settings))
                .orderByChild(mContext.getString(R.string.field_user_id))
                .equalTo(getItem(position).getUser_id());

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {

                    // currentUsername = singleSnapshot.getValue(UserAccountSettings.class).getUsername();
                    Log.d(TAG, "onDataChange: found user: "
                            + singleSnapshot.getValue(UserAccountSettings.class).getUsername());
                    Log.d(TAG, "onDataChange: found user: "
                            + singleSnapshot);

                    holder.username.setText(singleSnapshot.getValue(UserAccountSettings.class).getUsername());

                    final FirebaseAuth mAuth;
                    FirebaseAuth.AuthStateListener mAuthListener;
                    FirebaseDatabase mFirebaseDatabase;
                    DatabaseReference myRef;
                    FirebaseMethods mFirebaseMethods;
                    StorageReference mStorageReference;
                    final String userID;

                    mAuth = FirebaseAuth.getInstance();
                    mFirebaseDatabase = FirebaseDatabase.getInstance();
                    myRef = mFirebaseDatabase.getReference();
                    mStorageReference = FirebaseStorage.getInstance().getReference();

                    userID = mAuth.getCurrentUser().getUid();


                    final ViewHolder mHolder;
                    mHolder = holder;

                    final DatabaseReference s = (mReference.child(mContext.getString(R.string.dbname_photos))
                            .child(mHolder.photo.getPhoto_id()).child("price"));

                    s.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            try {
                                final long price = (dataSnapshot.getValue(Long.class));
                                Log.d(TAG, "onDataChange: price = " + price);
                                holder.price.setText("₹ " + String.valueOf(price));
                            }catch (NullPointerException e)
                            {}

                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                    counter = 0;
                    img__url = new String[10000];

                    final DatabaseReference typeref = (mReference.child(mContext.getString(R.string.dbname_photos))
                            .child(mHolder.photo.getPhoto_id()).child("type"));

                    typeref.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            long type;
                            try {
                                type = (dataSnapshot.getValue(Long.class));
                            }catch (NullPointerException e)
                            {
                                type = 1;
                            }

                            Log.d(TAG, "onDataChange: price = " + type);
                            final DatabaseReference img_ref = (mReference.child(mContext.getString(R.string.dbname_photos))
                                    .child(mHolder.photo.getPhoto_id()).child("image_path"));
                            //holder.price.setText("₹ " + String.valueOf(price));
                            if (type == 1) {
                                holder.ismultiple.setVisibility(View.GONE);
                                img_ref.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        String imgg;
                                        try {
                                            imgg = dataSnapshot.getValue().toString();
                                        }catch (NullPointerException e){
                                            imgg = "none";
                                        }
                                        imageLoader.displayImage(imgg, holder.image);
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                    }
                                });

                            } else if (type == 2) {
                                holder.ismultiple.setVisibility(View.VISIBLE);
                                img_ref.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {

                                        for (DataSnapshot childDataSnapshot : dataSnapshot.getChildren()) {
                                            img__url[counter] = childDataSnapshot.getValue(String.class);
                                            Log.d(TAG, "onDataChange: img__url[" + String.valueOf(counter) + "] = " + img__url[counter]);
                                            imageLoader.displayImage(img__url[0], holder.image);
                                            Log.d(TAG, " new test no : " + childDataSnapshot.getKey());
                                            Log.d(TAG, " new test url : " + childDataSnapshot.getValue());
                                            Log.d(TAG, " new test Count : " + String.valueOf(counter));
                                            counter++;
                                        }
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {

                                    }
                                });


                            }

                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                    final String[] urls = img_urls.toArray(new String[0]);
                    Log.d(TAG, "onDataChange: image url = " + img__url[0]);


                    holder.ismultiple.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            final DatabaseReference typeref = (mReference.child(mContext.getString(R.string.dbname_photos))
                                    .child(mHolder.photo.getPhoto_id()).child("type"));

                            typeref.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    final long type = (dataSnapshot.getValue(Long.class));
                                    Log.d(TAG, "onDataChange: type = " + type);
                                    //holder.price.setText("₹ " + String.valueOf(price));
                                    if (type == 2) {
                                        String img_id = mHolder.photo.getPhoto_id();
                                        //String img_url = mHolder.photo.getImage_path();
                                        ((HomeActivity) mContext).multi_show(img_id, urls, String.valueOf(type));
                                        ((HomeActivity) mContext).hideLayout();
                                    }

                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {

                                }
                            });


                        }
                    });

                    holder.save_to_my_store.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {


                        }
                    });


                    Log.d(TAG, "onDataChange: holder.user.getUsername() == " + holder.user.getUsername() + " currentUsername = " + currentUsername);

                    try {
                            holder.Buy_btn.setVisibility(View.VISIBLE);
                            String[] items = {"Share","Unfollow/Follow","Report"};
                            ArrayAdapter<String> adapter = new ArrayAdapter<String>((HomeActivity)mContext,R.layout.list_item,R.id.menu_item, items);
                            listView.setAdapter(adapter);
                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    ViewGroup vg = (ViewGroup)view;
                                    TextView txt = (TextView)vg.findViewById(R.id.menu_item);
                                    Toast.makeText((HomeActivity)mContext,txt.getText().toString(), Toast.LENGTH_LONG);
                                    Log.d(TAG, "onItemClick: trying to toast : "+ txt.getText().toString());
                                    switch (txt.getText().toString()){
                                        case "Unfollow/Follow":
                                            FirebaseDatabase.getInstance().getReference()
                                                    .child("following")
                                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                    .child(holder.user.getUser_id())
                                                    .removeValue();

                                            FirebaseDatabase.getInstance().getReference()
                                                    .child("followers")
                                                    .child(holder.user.getUser_id())
                                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                    .removeValue();
                                            break;

                                    }
                                }
                            });

                    }catch (Exception e)
                    {
                        Log.d(TAG, "onDataChange: e = " + e.toString());
                    }


                    holder.option.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            showDialogListView(v);

                        }
                    });


                    holder.Buy_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            s.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    final long price = (dataSnapshot.getValue(Long.class));

                                    Log.d(TAG, "onDataChange: going to buy now");
                                    Log.d(TAG, "onDataChange: user id should" + holder.user.getUser_id());
                                    String seller_id = holder.user.getUser_id();
                                    String current_user = currentUsername;
                                    String userN = holder.user.getUsername();
                                    ((HomeActivity)mContext).buy_now(userN,price,current_user,userID,seller_id,path_to_image,capton);
                                    //((HomeActivity)mContext).hideLayout();
                                }
                                @Override
                                public void onCancelled(DatabaseError databaseError) {

                                }
                            });
                        }
                    });


                    holder.save_to_my_store.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            s.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    final long price = (dataSnapshot.getValue(Long.class));
                                    ((HomeActivity)mContext).add_to_my_store(price,path_to_image,capton);
                                    ((HomeActivity)mContext).hideLayout();
                                }
                                @Override
                                public void onCancelled(DatabaseError databaseError) {

                                }
                            });
                        }
                    });

                    //initialize all images

                    try {
                        final String[] getImage = getItem(position).getImage_path().split(", ");
                        int counting = 0;
                        Log.d(TAG, "onDataChange: getimagepath() = " + getItem(position).getImage_path() + "String[] getImage = " + getImage);
                        for (String url : getImage) {
                            if (!url.equals("[null")) {
                                imageLoader.displayImage(url, holder.sharePhoto[counting]);
                                counting++;
                            }
                        }


                    //end initialize images

                    holder.share_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

//                            for(String path : urls) {
////                                File file = new File(path);
////                                Uri uri = Uri.fromFile(file);
//                                try {
//                                    if(!path.equals("[null")) {
//                                        URL url = new URL(path);
//                                        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//                                        Log.d(TAG, "onClick: share test path = " + url.toString());
//                                        Log.d(TAG, "onClick: share test path = " + path.toString());
//                                        connection.setDoInput(true);
//                                        connection.connect();
//                                        InputStream input = connection.getInputStream();
//
//                                        Bitmap image = BitmapFactory.decodeStream(input);
//                                        //Log.d(TAG, "onClick: share test = file = "+ uri +" "+file.toString() );
//                                        files.add(image);
//                                    }
//                                } catch(IOException e) {
//                                    System.out.println(e);
//                                }
//
//
//                            }

//

                            //intent.putExtra(Intent.EXTRA_SUBJECT, holder.caption.toString());
                            final DatabaseReference s = (mReference.child(mContext.getString(R.string.dbname_photos))
                                    .child(mHolder.photo.getPhoto_id()).child("price"));

                            s.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    ArrayList<Uri> file = new ArrayList<>();
                                    Log.d(TAG, "onClick: sharing url : "+ path_to_image);
                                    Drawable[] mDrawable = new Drawable[getImage.length];
                                    Bitmap[] mBitmap = new Bitmap[getImage.length];
                                    for(int n=0;n<getImage.length;n++) {
                                        mDrawable[n] = holder.sharePhoto[n].getDrawable();
                                        try {
                                            mBitmap[n] = ((BitmapDrawable) mDrawable[n]).getBitmap();
                                            Log.d(TAG, "onClick: share test = urls = " + urls);
                                            String path = MediaStore.Images.Media.insertImage(mContext.getContentResolver(), mBitmap[n], "Image Description", null);
                                            Uri uri = Uri.parse(path);
                                            file.add(uri);
                                        }catch (Exception e)
                                        {
                                        }
                                    }
                                    try {
                                        Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                                        intent.setType("image/jpeg");
                                        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, file);
                                        final long price = (dataSnapshot.getValue(Long.class));
                                        intent.putExtra(Intent.EXTRA_TEXT, capton+" \nPrice : ₹ "+ price);
                                        mContext.startActivity(intent);
                                    }catch (NullPointerException e)
                                    {}

                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {

                                }
                            });



                        }
                    });
                    }catch (Exception e)
                    {

                    }



                    /// Log.d(TAG, "onDataChange: price = " + s);

                    holder.username.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Log.d(TAG, "onClick: navigating to profile of: " +
                                    holder.user.getUsername());

                            Intent intent = new Intent(mContext, ProfileActivity.class);
                            intent.putExtra(mContext.getString(R.string.calling_activity),
                                    mContext.getString(R.string.home_activity));
                            intent.putExtra(mContext.getString(R.string.intent_user), holder.user);
                            mContext.startActivity(intent);
                        }
                    });



                    imageLoader.displayImage(singleSnapshot.getValue(UserAccountSettings.class).getProfile_photo(),
                            holder.mprofileImage);
                    holder.mprofileImage.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Log.d(TAG, "onClick: navigating to profile of: " +
                                    holder.user.getUsername());

                            Intent intent = new Intent(mContext, ProfileActivity.class);
                            intent.putExtra(mContext.getString(R.string.calling_activity),
                                    mContext.getString(R.string.home_activity));
                            intent.putExtra(mContext.getString(R.string.intent_user), holder.user);
                            mContext.startActivity(intent);
                        }
                    });



                    holder.settings = singleSnapshot.getValue(UserAccountSettings.class);
                    holder.comment.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ((HomeActivity)mContext).onCommentThreadSelected(getItem(position),
                                    mContext.getString(R.string.home_activity));

                            //another thing?
                            ((HomeActivity)mContext).hideLayout();
                        }
                    });
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });




        //get the user object
        Query userQuery = mReference
                .child(mContext.getString(R.string.dbname_users))
                .orderByChild(mContext.getString(R.string.field_user_id))
                .equalTo(getItem(position).getUser_id());
        userQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot singleSnapshot : dataSnapshot.getChildren()){
                    Log.d(TAG, "onDataChange: found user: " +
                    singleSnapshot.getValue(User.class).getUsername());

                    holder.user = singleSnapshot.getValue(User.class);
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        if(reachedEndOfList(position)){
            loadMoreData();
        }

        return convertView;
    }

    private boolean reachedEndOfList(int position){
        return position == getCount() - 1;
    }

    private void loadMoreData(){

        try{
            mOnLoadMoreItemsListener = (OnLoadMoreItemsListener) getContext();
        }catch (ClassCastException e){
            Log.e(TAG, "loadMoreData: ClassCastException: " +e.getMessage() );
        }

        try{
            mOnLoadMoreItemsListener.onLoadMoreItems();
        }catch (NullPointerException e){
            Log.e(TAG, "loadMoreData: ClassCastException: " +e.getMessage() );
        }
    }

    public class GestureListener extends GestureDetector.SimpleOnGestureListener{

        ViewHolder mHolder;
        public GestureListener(ViewHolder holder) {
            mHolder = holder;
        }

 //       @Override
 //       public boolean onDown(MotionEvent e) {
 //           return true;
 //       }

        @Override
        public boolean onDown(MotionEvent e) {
            Log.d(TAG, "onDoubleTap: double tap detected.");

            Log.d(TAG, "onDoubleTap: clicked on photo: " + mHolder.photo.getPhoto_id());

            final DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
            final String currentDateandTime = sdf.format(new Date());

            final String mGroupId = reference.child("notification").child(mHolder.photo.getUser_id()).push().getKey();



            Query query = reference
                    .child(mContext.getString(R.string.dbname_photos))
                    .child(mHolder.photo.getPhoto_id())
                    .child(mContext.getString(R.string.field_likes));
            query.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for(DataSnapshot singleSnapshot : dataSnapshot.getChildren()){

                        String keyID = singleSnapshot.getKey();

                        //case1: Then user already liked the photo
                        if(mHolder.likeByCurrentUser
//                                && singleSnapshot.getValue(Like.class).getUser_id()
//                                        .equals(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                ){

                            mReference.child(mContext.getString(R.string.dbname_photos))
                                    .child(mHolder.photo.getPhoto_id())
                                    .child(mContext.getString(R.string.field_likes))
                                    .child(keyID)
                                    .removeValue();
///
                            mReference.child(mContext.getString(R.string.dbname_user_photos))
//                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .child(mHolder.photo.getUser_id())
                                    .child(mHolder.photo.getPhoto_id())
                                    .child(mContext.getString(R.string.field_likes))
                                    .child(keyID)
                                    .removeValue();
                            reference.child("notification").child(mHolder.photo.getUser_id()).child(mGroupId).removeValue();

                            mHolder.heart.toggleLike();
                            getLikesString(mHolder);
                        }
                        //case2: The user has not liked the photo
                        else if(!mHolder.likeByCurrentUser){
                            //add new like
                            addNewLike(mHolder);
                            break;
                        }
                    }
                    if(!dataSnapshot.exists()){
                        //add new like
                        reference.child("notification").child(mHolder.photo.getUser_id()).child(mGroupId).child("by_user").setValue(currentUsername);
                        reference.child("notification").child(mHolder.photo.getUser_id()).child(mGroupId).child("type").setValue("like");
                        reference.child("notification").child(mHolder.photo.getUser_id()).child(mGroupId).child("seen").setValue("unseen");
                        reference.child("notification").child(mHolder.photo.getUser_id()).child(mGroupId).child("time").setValue(currentDateandTime);
                        reference.child("notification").child(mHolder.photo.getUser_id()).child(mGroupId).child("like_id").setValue(mGroupId);
                        addNewLike(mHolder);
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

            return true;
        }
    }

    private void addNewLike(final ViewHolder holder){
        Log.d(TAG, "addNewLike: adding new like");

        String newLikeID = mReference.push().getKey();
        Like like = new Like();
        like.setUser_id(FirebaseAuth.getInstance().getCurrentUser().getUid());

        mReference.child(mContext.getString(R.string.dbname_photos))
                .child(holder.photo.getPhoto_id())
                .child(mContext.getString(R.string.field_likes))
                .child(newLikeID)
                .setValue(like);

        mReference.child(mContext.getString(R.string.dbname_user_photos))
                .child(holder.photo.getUser_id())
                .child(holder.photo.getPhoto_id())
                .child(mContext.getString(R.string.field_likes))
                .child(newLikeID)
                .setValue(like);

        holder.heart.toggleLike();
        getLikesString(holder);
    }

    private void getCurrentUsername(){
        Log.d(TAG, "getCurrentUsername: retrieving user account settings");
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        Query query = reference
                .child(mContext.getString(R.string.dbname_users))
                .orderByChild(mContext.getString(R.string.field_user_id))
                .equalTo(FirebaseAuth.getInstance().getCurrentUser().getUid());
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot singleSnapshot : dataSnapshot.getChildren()){
                    currentUsername = singleSnapshot.getValue(UserAccountSettings.class).getUsername();
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void getLikesString(final ViewHolder holder){
        Log.d(TAG, "getLikesString: getting likes string");

        Log.d(TAG, "getLikesString: photo id: " + holder.photo.getPhoto_id());
        try{
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        Query query = reference
                .child(mContext.getString(R.string.dbname_photos))
                .child(holder.photo.getPhoto_id())
                .child(mContext.getString(R.string.field_likes));
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                holder.users = new StringBuilder();
                for(DataSnapshot singleSnapshot : dataSnapshot.getChildren()){

                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
                    Query query = reference
                            .child(mContext.getString(R.string.dbname_users))
                            .orderByChild(mContext.getString(R.string.field_user_id))
                            .equalTo(singleSnapshot.getValue(Like.class).getUser_id());
                    query.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            for(DataSnapshot singleSnapshot : dataSnapshot.getChildren()){
                                Log.d(TAG, "onDataChange: found like: " +
                                        singleSnapshot.getValue(User.class).getUsername());

                                holder.users.append(singleSnapshot.getValue(User.class).getUsername());
                                holder.users.append(",");
                            }

                            String[] splitUsers = holder.users.toString().split(",");

                            if(holder.users.toString().contains(currentUsername + ",")){//mitch, mitchell.tabian
                                holder.likeByCurrentUser = true;
                            }else{
                                holder.likeByCurrentUser = false;
                            }

                            int length = splitUsers.length;
                            if(length==0)
                            {
                                holder.likesString = "0 Likes";
                            }
                            else if(length == 1){
                                holder.likesString = "Liked by " + splitUsers[0];
                            }
                            else if(length == 2){
                                holder.likesString = "Liked by " + splitUsers[0]
                                        + " and " + splitUsers[1];
                            }
                            else if(length == 3){
                                holder.likesString = "Liked by " + splitUsers[0]
                                        + ", " + splitUsers[1]
                                        + " and " + splitUsers[2];

                            }
                            else if(length == 4){
                                holder.likesString = "Liked by " + splitUsers[0]
                                        + ", " + splitUsers[1]
                                        + ", " + splitUsers[2]
                                        + " and " + splitUsers[3];
                            }
                            else if(length > 4){
                                holder.likesString = "Liked by " + splitUsers[0]
                                        + ", " + splitUsers[1]
                                        + ", " + splitUsers[2]
                                        + " and " + (splitUsers.length - 3) + " others";
                            }
                            Log.d(TAG, "onDataChange: likes string: " + holder.likesString);
                            //setup likes string
                            setupLikesString(holder, holder.likesString);
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }
                if(!dataSnapshot.exists()){
                    holder.likesString = "0 Likes";
                    holder.likeByCurrentUser = false;
                    //setup likes string
                    setupLikesString(holder, holder.likesString);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        }catch (NullPointerException e){
            Log.e(TAG, "getLikesString: NullPointerException: " + e.getMessage() );
            holder.likesString = "";
            holder.likeByCurrentUser = false;
            //setup likes string
            setupLikesString(holder, holder.likesString);
        }
    }

    private void setupLikesString(final ViewHolder holder, String likesString){
        Log.d(TAG, "setupLikesString: likes string:" + holder.likesString);

        Log.d(TAG, "setupLikesString: photo id: " + holder.photo.getPhoto_id());
        if(holder.likeByCurrentUser){
            Log.d(TAG, "setupLikesString: photo is liked by current user");
            holder.heartWhite.setVisibility(View.GONE);
            holder.heartRed.setVisibility(View.VISIBLE);
            holder.heartRed.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return holder.detector.onTouchEvent(event);
                }
            });
        }else{
            Log.d(TAG, "setupLikesString: photo is not liked by current user");
            holder.heartWhite.setVisibility(View.VISIBLE);
            holder.heartRed.setVisibility(View.GONE);
            holder.heartWhite.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return holder.detector.onTouchEvent(event);
                }
            });
        }
        holder.likes.setText(likesString);
    }

    /**
     * Returns a string representing the number of days ago the post was made
     * @return
     */
    private String getTimestampDifference(Photo photo){
        Log.d(TAG, "getTimestampDifference: getting timestamp difference.");

        String difference = "";
        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.CANADA);
        sdf.setTimeZone(TimeZone.getTimeZone("Canada/Pacific"));//google 'android list of timezones'
        Date today = c.getTime();
        sdf.format(today);
        Date timestamp;
        final String photoTimestamp = photo.getDate_created();
        try{
            timestamp = sdf.parse(photoTimestamp);
            difference = String.valueOf(Math.round(((today.getTime() - timestamp.getTime()) / 1000 / 60 / 60 / 24 )));
        }catch (ParseException e){
            Log.e(TAG, "getTimestampDifference: ParseException: " + e.getMessage() );
            difference = "0";
        }
        return difference;
    }

    public void showDialogListView(View view)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder((HomeActivity)mContext);
        builder.setCancelable(true);

        builder.setView(listView);
        AlertDialog dialog = builder.create();
        dialog.show();
        builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                listView=null;
                dialog.cancel();
            }
        });
    }



}





























