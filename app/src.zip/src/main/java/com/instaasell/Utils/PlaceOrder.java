package com.instaasell.Utils;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.eschao.android.widget.elasticlistview.ElasticListView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.instaasell.R;
import com.instaasell.models.Photo;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class PlaceOrder extends AppCompatActivity {

    private final String TAG = "Place Order : ";

    private TextView Cust_name,Phone,flat,Street,City,State,Pin;
    private Button ptp;
    private String userS;
    private ImageView photo;
    public int order_no;

    @Override
    public void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        setContentView(R.layout.layout_place_order);
        init();


    }

    public void init()
    {

        TextView caption_view = (TextView)findViewById(R.id.caption);
        ImageView img_view = (ImageView) findViewById(R.id.preview_img);
        TextView price_view = (TextView)findViewById(R.id.price);

        Cust_name = (TextView) findViewById(R.id.CustomerName);
        Phone = (TextView) findViewById(R.id.PhoneNo);
        flat = (TextView) findViewById(R.id.BuildingAddress);
        photo = (ImageView) findViewById(R.id.preview_img);
        Street = (TextView) findViewById(R.id.StreetAddress);
        State = (TextView) findViewById(R.id.State);
        City = (TextView) findViewById(R.id.CustomerName);
        Pin = (TextView) findViewById(R.id.pin);
        ptp = (Button) findViewById(R.id.ptp);

        Bundle bundle = getIntent().getExtras();
        String seller = bundle.getString("seller_username");
        String price = bundle.getString("price");
        String current_U = bundle.getString("current_user");
        String img_url = bundle.getString("img_url");
        String caption = bundle.getString("caption");
        caption_view.setText(caption);
        Picasso.get().load(img_url).into(img_view);
        price_view.setText("₹ "+price);
        ptp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upload_details();
                setContentView(R.layout.order_success);
            }
        });
    }

    public void upload_details()
    {


        final FirebaseAuth mAuth;
        final FirebaseAuth.AuthStateListener mAuthListener;
        final FirebaseDatabase mFirebaseDatabase;
        final DatabaseReference myRef;
        final FirebaseMethods mFirebaseMethods;
        final StorageReference mStorageReference;
        final String userID;

        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();

        mStorageReference = FirebaseStorage.getInstance().getReference();
        final Bundle bundle = getIntent().getExtras();
        final String seller = bundle.getString("seller_username");
        final String price = bundle.getString("price");
        final String current_U = bundle.getString("current_user");
        final String img_url = bundle.getString("img_url");
        final String caption = bundle.getString("caption");


//        if(mAuth.getCurrentUser() != null){
//            userID = mAuth.getCurrentUser().getUid();
//        }
        final String key = myRef.child("buy").push().getKey();



        userID = mAuth.getCurrentUser().getUid();
        if(Cust_name.getText().equals("") && Phone.getText().equals("") && flat.getText().equals("") && Street.getText().equals("") && State.getText().equals("") && City.getText().equals("") && Pin.getText().equals("") )
        {
            Toast toast = Toast.makeText(getApplicationContext(), "All fields Are mandatory", Toast.LENGTH_SHORT); toast.show();
        }
        else
        {
            //Buy Database Entries
            //order no
            myRef.child("next_count").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    String date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                    order_no = dataSnapshot.getValue(Integer.class);
                    Log.d(TAG, "onDataChange: order_no = " + order_no);
                    increment_order_count(order_no);
                    String seller_uid = bundle.getString("seller_uid");
                    Log.d(TAG, "upload_details: seller = " + seller);
                    myRef.child("buy").child(userID).child(key).child("seller").setValue(seller);
                    myRef.child("buy").child(userID).child(key).child("price").setValue(price);
                    myRef.child("buy").child(userID).child(key).child("order_id").setValue(key);
                    myRef.child("buy").child(userID).child(key).child("order_no").setValue(order_no);
                    myRef.child("buy").child(userID).child(key).child("name").setValue(Cust_name.getText().toString());
                    myRef.child("buy").child(userID).child(key).child("phone").setValue(Phone.getText().toString());
                    myRef.child("buy").child(userID).child(key).child("flat").setValue(flat.getText().toString());
                    myRef.child("buy").child(userID).child(key).child("street").setValue(Street.getText().toString());
                    myRef.child("buy").child(userID).child(key).child("state").setValue(State.getText().toString());
                    myRef.child("buy").child(userID).child(key).child("city").setValue(City.getText().toString());
                    myRef.child("buy").child(userID).child(key).child("pin").setValue(Pin.getText().toString());
                    myRef.child("buy").child(userID).child(key).child("imgurl").setValue(img_url);
                    myRef.child("buy").child(userID).child(key).child("caption").setValue(caption);
                    myRef.child("buy").child(userID).child(key).child("seller_id").setValue(seller_uid);
                    myRef.child("buy").child(userID).child(key).child("track").child("status").setValue("0");
                    myRef.child("buy").child(userID).child(key).child("date").setValue(date);
                    //sell Database Entries
                    myRef.child("sell").child(seller_uid).child(key).child("buyer").setValue(current_U);
                    myRef.child("sell").child(seller_uid).child(key).child("price").setValue(price);
                    myRef.child("sell").child(seller_uid).child(key).child("order_no").setValue(order_no);
                    myRef.child("sell").child(seller_uid).child(key).child("order_id").setValue(key);
                    myRef.child("sell").child(seller_uid).child(key).child("name").setValue(Cust_name.getText().toString());
                    myRef.child("sell").child(seller_uid).child(key).child("phone").setValue(Phone.getText().toString());
                    myRef.child("sell").child(seller_uid).child(key).child("flat").setValue(flat.getText().toString());
                    myRef.child("sell").child(seller_uid).child(key).child("street").setValue(Street.getText().toString());
                    myRef.child("sell").child(seller_uid).child(key).child("state").setValue(State.getText().toString());
                    myRef.child("sell").child(seller_uid).child(key).child("city").setValue(City.getText().toString());
                    myRef.child("sell").child(seller_uid).child(key).child("pin").setValue(Pin.getText().toString());
                    myRef.child("sell").child(seller_uid).child(key).child("imgurl").setValue(img_url);
                    myRef.child("sell").child(seller_uid).child(key).child("caption").setValue(caption);
                    myRef.child("sell").child(seller_uid).child(key).child("buyer_id").setValue(userID);
                    myRef.child("sell").child(seller_uid).child(key).child("track").child("status").setValue("0");
                    myRef.child("sell").child(seller_uid).child(key).child("date").setValue(date);

                    myRef.child("mywallet").child(userID).child(key).child("orderno").setValue(String.valueOf(order_no));
                    myRef.child("mywallet").child(userID).child(key).child("price").setValue(price);
                    myRef.child("mywallet").child(userID).child(key).child("date").setValue(date);
                    myRef.child("mywallet").child(userID).child(key).child("imgurl").setValue(img_url);
                    myRef.child("mywallet").child(userID).child(key).child("type").setValue("1");
                    myRef.child("mywallet").child(seller_uid).child(key).child("orderno").setValue(String.valueOf(order_no));
                    myRef.child("mywallet").child(seller_uid).child(key).child("price").setValue(price);
                    myRef.child("mywallet").child(seller_uid).child(key).child("date").setValue(date);
                    myRef.child("mywallet").child(seller_uid).child(key).child("imgurl").setValue(img_url);
                    myRef.child("mywallet").child(seller_uid).child(key).child("type").setValue("2");

                    //notification
                    final String mGroupId = myRef.child("notification").child(seller_uid).push().getKey();
                    myRef.child("notification").child(seller_uid).child(mGroupId).child("by_user").setValue(current_U);
                    myRef.child("notification").child(seller_uid).child(mGroupId).child("type").setValue("order");
                    myRef.child("notification").child(seller_uid).child(mGroupId).child("time").setValue(date);
                    myRef.child("notification").child(seller_uid).child(mGroupId).child("id").setValue(mGroupId);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
            //Wallet buy
            Toast toast = Toast.makeText(getApplicationContext(), "Uploaded", Toast.LENGTH_SHORT); toast.show();
        }
    }

    public int increment_order_count(int count_no)
    {
        try {
            DatabaseReference myRef;
            myRef = FirebaseDatabase.getInstance().getReference();
            Log.d(TAG, "upload_details: order no = " + order_no);
            myRef.child("next_count").setValue(order_no + 1);
        }catch (Exception e)
        {
            Log.d(TAG, "increment_order_count: exception"+ e.toString());
        }
        return count_no-1;
    }


}
