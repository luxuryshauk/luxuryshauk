package com.instaasell.Utils;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.instaasell.Home.HomeActivity;
import com.instaasell.Profile.AccountSettingsActivity;
import com.instaasell.Profile.CashoutActivity;
import com.instaasell.R;
import com.instaasell.models.order;
import com.instaasell.models.order_sell;
import com.instaasell.models.wallet;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.Arrays;

public class MyWallet extends Fragment {

    String TAG = "Mywallet";

    FirebaseListAdapter adapter;
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference myRef;
    FirebaseMethods mFirebaseMethods;
    StorageReference mStorageReference;
    String userID;
    ListView w_sum;
    public float blnce=0f;
    boolean[] added;
    int count=1;

    long total=0,sell_total=0,buy_total=0;


    @Nullable
    @Override
    public View onCreateView(final LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.layout_mywallet, container, false);
        added = new boolean[10000000];
        Arrays.fill(added, Boolean.FALSE);
        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        mStorageReference = FirebaseStorage.getInstance().getReference();
        userID = mAuth.getCurrentUser().getUid();
        final TextView balance = (TextView) view.findViewById(R.id.Balance_wallet);
        final Button cashout_btn = (Button) view.findViewById(R.id.cashout_btn);

        w_sum = (ListView) view.findViewById(R.id.wallet_summary);
        Query mQueryRef = myRef.child("mywallet").child(userID);
        FirebaseListOptions<wallet> options = new FirebaseListOptions.Builder<wallet>()
                .setLayout(R.layout.snippet_wallet)
                .setQuery(mQueryRef, wallet.class)
                .setLifecycleOwner(getActivity())
                .build();
        Log.d(TAG, "onCreateView: adapter starting");
        adapter = new FirebaseListAdapter(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull Object model, int position) {
                Log.d(TAG, "populateView: adapter started");
                TextView no = (TextView) v.findViewById(R.id.order_id);
                Log.d(TAG, "populateView: balance = " + blnce);
                TextView caption = (TextView) v.findViewById(R.id.caption);
                final TextView date_1 = (TextView) v.findViewById(R.id.date);
                TextView price = (TextView) v.findViewById(R.id.price);
                ImageView img = (ImageView) v.findViewById(R.id.product);
                wallet Wallet = (wallet) model;
                Log.d(TAG, "populateView: array is : " + Integer.parseInt(Wallet.getOrderno()));
                Log.d(TAG, "populateView: array is string : " + Wallet.getOrderno());
                Log.d(TAG, "populateView: array is bool : " + added[Integer.parseInt(Wallet.getOrderno())]);
                try {
                    if (Wallet.getType().equals("1")) {
                        price.setText("+ ₹ " + Wallet.getPrice());
                        no.setText("ORDER ID #" + Wallet.getOrderno());
                        if (!added[Integer.parseInt(Wallet.getOrderno())]) {
                            blnce += Float.valueOf(Wallet.getPrice());
                            added[Integer.parseInt(Wallet.getOrderno())] = true;
                        }
                        caption.setText("Earned for Order");
                        Log.d(TAG, "populateView: earn balance = " + blnce);
                        Picasso.get().load(Wallet.getImgurl()).into(img);
                        date_1.setText(Wallet.getDate());
                    } else if (Wallet.getType().equals("2")) {
                        price.setText("- ₹ " + Wallet.getPrice());
                        no.setText("ORDER ID #" + Wallet.getOrderno());
                        if (!added[Integer.parseInt(Wallet.getOrderno())]) {
                            blnce -= Float.valueOf(Wallet.getPrice());
                            added[Integer.parseInt(Wallet.getOrderno())] = true;
                        }
                        caption.setText("Spend on Order");
                        Log.d(TAG, "populateView: spend balance = " + blnce);
                        Picasso.get().load(Wallet.getImgurl()).into(img);
                        date_1.setText(Wallet.getDate());
                    } else if (Wallet.getType().equals("3")) {
                        price.setText("- ₹ " + Wallet.getPrice());
                        no.setText("ORDER ID #" + Wallet.getOrderno());
                        if (!added[Integer.parseInt(Wallet.getOrderno())]) {
                            blnce -= Float.valueOf(Wallet.getPrice());
                            added[Integer.parseInt(Wallet.getOrderno())] = true;
                        }
                        Log.d(TAG, "populateView: withdrawl balance = " + blnce);
                        caption.setText("Withdrawal");
                        date_1.setText(Wallet.getDate());
                    }
                    cashout_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Log.d(TAG, "populateView: final balance(inside button on click) =  " + blnce);
                            Intent intent = new Intent(getActivity(), CashoutActivity.class);
                            intent.putExtra("tbal", blnce);
                            startActivity(intent);
                        }
                    });
                    Log.d(TAG, "populateView: final balance = " + blnce);
                    Log.d(TAG, "populateView: working : true");
                    balance.setText("= ₹ " + String.valueOf(blnce) + "/-");
                }catch (NullPointerException e)
                {
                    Log.d(TAG, "populateView: exception " + e.toString());
                }
            }
        };
        Log.d(TAG, "onCreateView: final price = "+balance.getText().toString());
        w_sum.setAdapter(adapter);

        return view;
    }
}
