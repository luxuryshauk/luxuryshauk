package com.instaasell.Utils;

public interface FragmentOnBackClickInterface {
    void onBackPressed();
}
