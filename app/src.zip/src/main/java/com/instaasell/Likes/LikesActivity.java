package com.instaasell.Likes;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.instaasell.Utils.FirebaseMethods;
import com.instaasell.Utils.sell;
import com.instaasell.models.Comment;
import com.instaasell.models.notification;
import com.instaasell.models.order_sell;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

import com.instaasell.R;
import com.instaasell.Utils.BottomNavigationViewHelper;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by User on 5/28/2017.
 */

public class LikesActivity extends AppCompatActivity{
    private static final String TAG = "LikesActivity";
    private static final int ACTIVITY_NUM = 3;

    ListView lv;
    FirebaseListAdapter adapter;
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference myRef;
    FirebaseMethods mFirebaseMethods;
    StorageReference mStorageReference;
    String userID;
    private LinearLayoutManager mLayoutManager;


    private Context mContext = LikesActivity.this;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_notifications);
        Log.d(TAG, "onCreate: started.");
        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        mStorageReference = FirebaseStorage.getInstance().getReference();
        userID = mAuth.getCurrentUser().getUid();
        lv = (ListView) findViewById(R.id.notifications);
        Query query = FirebaseDatabase.getInstance().getReference().child("notification").child(userID);
        FirebaseListOptions<notification> options = new FirebaseListOptions.Builder<notification>()
                .setLayout(R.layout.fragment_notification)
                .setQuery(query, notification.class)
                .setLifecycleOwner(LikesActivity.this)
                .build();
        adapter = new FirebaseListAdapter(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull Object model, int position) {
                final CircleImageView profile_pic = v.findViewById(R.id.profilepic);
                TextView comment = v.findViewById(R.id.comments);
                TextView time = v.findViewById(R.id.time);
                TextView empty = findViewById(R.id.empty_not);
                notification Notification = (notification) model;
                String timestampDifference = getTimestampDifference(Notification);

                myRef.child("user_account_settings").child(userID).child("profile_photo").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String imgurl = dataSnapshot.getValue(String.class);
                        Picasso.get().load(imgurl).into(profile_pic);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                try
                {
                    if(Notification.getBy_user()!=null)
                    {
                        if(Notification.getType().equals("like"))
                        {
                            empty.setVisibility(View.GONE);
                            comment.setText(Notification.getBy_user() + " liked your post");

                        }else if(Notification.getType().equals("comments")){
                            empty.setVisibility(View.GONE);
                            comment.setText(Notification.getBy_user() + " commented on your post");

                        }else if(Notification.getType().equals("order"))
                        {
                            empty.setVisibility(View.GONE);
                            comment.setText(Notification.getBy_user() + " placed an order");
                        }
                        if(!timestampDifference.equals("0")){
                            time.setText(timestampDifference + " d");
                        }else{
                            time.setText("today");
                        }


                    }
                }catch(Exception e) {
                    System.out.println(e);
                }
            }
        };
        lv.setAdapter(adapter);

        setupBottomNavigationView();
    }
    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    private String getTimestampDifference(notification Notification){
        Log.d(TAG, "getTimestampDifference: getting timestamp difference.");

        String difference = "";
        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.CANADA);
        sdf.setTimeZone(TimeZone.getTimeZone("Canada/Pacific"));//google 'android list of timezones'
        Date today = c.getTime();
        sdf.format(today);
        Date timestamp;
        final String photoTimestamp = Notification.getTime();
        try{
            timestamp = sdf.parse(photoTimestamp);
            difference = String.valueOf(Math.round(((today.getTime() - timestamp.getTime()) / 1000 / 60 / 60 / 24 )));
        }catch (ParseException e){
            Log.e(TAG, "getTimestampDifference: ParseException: " + e.getMessage() );
            difference = "0";
        }
        return difference;
    }

    /**
     * BottomNavigationView setup
     */
    private void setupBottomNavigationView(){
        Log.d(TAG, "setupBottomNavigationView: setting up BottomNavigationView");
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setupBottomNavigationView(bottomNavigationViewEx);
        BottomNavigationViewHelper.enableNavigation(mContext, this,bottomNavigationViewEx);
        Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(ACTIVITY_NUM);
        menuItem.setChecked(true);
    }
}
