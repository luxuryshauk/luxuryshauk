package com.instaasell.Profile;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.googlecode.mp4parser.authoring.Edit;
import com.instaasell.Home.AddActivity;
import com.instaasell.Home.HomeActivity;
import com.instaasell.R;
import com.instaasell.Utils.FirebaseMethods;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CashoutActivity extends AppCompatActivity {

    public static final String TAG = "Cashout Activity";
    Context mContext = CashoutActivity.this;
    public int order_no;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_cashout);
        Bundle bundle = getIntent().getExtras();
        final float bal = bundle.getFloat("tbal");
        final TextView amount = findViewById(R.id.amount);
        final EditText holder = findViewById(R.id.holder);
        final EditText accno = findViewById(R.id.acc_no);
        final EditText bank = findViewById(R.id.bank_name);
        final EditText ifsc = findViewById(R.id.ifsc);
        Button r_c = findViewById(R.id.casho_btn);

        amount.setText("Wallet Amount = ₹ "+bal +"/-");
        r_c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String holder_s = holder.getText().toString();
                String accno_s = accno.getText().toString();
                String bank_s = bank.getText().toString();
                String ifsc_s = ifsc.getText().toString();
                if(!holder_s.equals("")&&!accno_s.equals("")&&!bank_s.equals("")&&!ifsc_s.equals(""))
                {
                    String date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                    final FirebaseAuth mAuth;
                    final FirebaseAuth.AuthStateListener mAuthListener;
                    final FirebaseDatabase mFirebaseDatabase;
                    final DatabaseReference myRef;
                    final FirebaseMethods mFirebaseMethods;
                    final StorageReference mStorageReference;
                    final String userID;
                    mAuth = FirebaseAuth.getInstance();
                    mFirebaseDatabase = FirebaseDatabase.getInstance();
                    final FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser() ;
                    myRef = mFirebaseDatabase.getReference();
                    myRef.child("next_count").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            String date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                            order_no = dataSnapshot.getValue(Integer.class);
                            Log.d(TAG, "onDataChange: order_no = " + order_no);
                            increment_order_count(order_no);
                            final String key = myRef.child("buy").push().getKey();
                            myRef.child("mywallet").child(currentFirebaseUser.getUid()).child(key).child("price").setValue(String.valueOf(bal));
                            myRef.child("mywallet").child(currentFirebaseUser.getUid()).child(key).child("date").setValue(date);
                            myRef.child("mywallet").child(currentFirebaseUser.getUid()).child(key).child("type").setValue("3");
                            myRef.child("mywallet").child(currentFirebaseUser.getUid()).child(key).child("orderno").setValue(String.valueOf(order_no));
                            Toast.makeText(mContext,"Success",Toast.LENGTH_SHORT).show();
                            setContentView(R.layout.cashout_success_fragment);
                            Button back = findViewById(R.id.goback);
                            back.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    finish();
                                    startActivity(new Intent(CashoutActivity.this, HomeActivity.class));
                                }
                            });
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                        }
                    });
                }else{
                    Toast.makeText(mContext,"All fields are mandatory",Toast.LENGTH_SHORT).show();
                }
            }
        });



        Log.d(TAG, "onCreate: total = "+bal);
    }
    public int increment_order_count(int count_no)
    {
        try {
            DatabaseReference myRef;
            myRef = FirebaseDatabase.getInstance().getReference();
            Log.d(TAG, "upload_details: order no = " + order_no);
            myRef.child("next_count").setValue(order_no + 1);
        }catch (Exception e)
        {
            Log.d(TAG, "increment_order_count: exception"+ e.toString());
        }
        return count_no-1;
    }
}
